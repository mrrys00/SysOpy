#include <stdio.h>
#include <stdlib.h>

void temp () {
    printf("fuck off\n");
}

int main(int argc, char *argv[]) {
//    int a = system("[ -p ./test.c ] && echo OK || err ");
//    printf("a = %d\n", a);
    int b = -1;
    if (b) {
        printf("fuck");
    }
    return 0;
}